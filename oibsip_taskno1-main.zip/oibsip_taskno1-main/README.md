f# oibsip_taskno1
This was a task given by Oasis Infobyte while Android App Development Internship 
Unit Converter App
The KFC app demonstrates the conversion of temperature units.
Java And XML is used along with android studio

Check out this video:
https://youtu.be/Bf9C-_srGQI
